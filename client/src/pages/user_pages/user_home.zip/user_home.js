import { Link, NavLink } from "react-router-dom"
import axios from "axios";
import { useEffect, useState } from "react";
import { FaIndianRupeeSign } from "react-icons/fa6";
import { ContinousSlider } from "../../components/continousSlider";
import { Slider } from "../../components/homeTopSlider";
import { BrandBudget } from "../../components/brand&budget";
import { Testimonials } from "../../components/testimonial_slider";

export const UserHome = () => {

    const [product, setProduct] = useState([]);
    const [dell, setDell] = useState([]);
    const [hp, setHp] = useState([]);


    const getAllProducts = () => {
        axios
            .get("http://localhost:1000/api/user/products")
            .then((res) => setProduct(res.data))
            .catch((err) => console.log(err, "It has an error"))
    }

    const getDellLaptops = async () => {
        const response = await fetch(`http://localhost:1000/api/user/category/filterData/65cc8866264789916da18bd4`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json"
            }
        });

        if (response.status === 200) {
            const filterData = await response.json();
            console.log(filterData);
            setDell(filterData);
        }
    }

    const getHpLaptops = async () => {
        const response = await fetch(`http://localhost:1000/api/user/category/filterData/65cbab3447f3a0198a40b59a`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json"
            }
        });

        if (response.status === 200) {
            const filterData = await response.json();
            console.log(filterData);
            setHp(filterData);
        }
    }

    useEffect(() => {
        getAllProducts();
        getDellLaptops();
        getHpLaptops();
    }, [])



    return (
        <>
            {/* Home Top Slider */}
            <Slider />

            {/* Brand & Budget */}
            <BrandBudget />

            {/* Fresh Arrivals */}
            <div className="freshArrivalheading">
                <h1>Fresh Arrivals</h1>
            </div>
            <div className=" productsData container-grid ">
                {
                    product.slice(0, 4).map((currentProduct, index) => {
                        const base64String = btoa(
                            String.fromCharCode(...new Uint8Array(currentProduct.pImage.data.data))
                        );

                        return (
                            <div className=" productCard " key={index}>
                                <NavLink to={`/user/product-details/${currentProduct.pToken}`}>
                                    <div className="card-img">
                                        <img src={`data: image/png;base64, ${base64String}`} alt="Product Img" width="250px" height="250px" />
                                    </div>
                                    <div className="card-details">
                                        <div className="product-name">
                                            <h4>{currentProduct.pBrand}</h4>
                                        </div>
                                        <div className="product-price">
                                            <h4><FaIndianRupeeSign /> {currentProduct.pPrice}</h4>
                                        </div>
                                        <div className="product-description">
                                            <p className="fw-light">{currentProduct.pDescription}</p>
                                        </div>

                                    </div>
                                </NavLink>
                            </div>
                        )
                    })
                }
            </div >
            <div className="freshArrivalbtn text-center ">
                <Link to="/category/filterData/fresharrival">
                    <button ><h6>VIEW ALL</h6></button>
                </Link>
            </div>

            <br />
            <br />
            {/* Shop by Usage */}
            <div className="freshArrivalheading">
                <h1>Shop By Usage</h1>
            </div>
            <div className="usageCards productsData">
                <NavLink to="/category/filterData/65cbaab247f3a0198a40b458">
                    <img src="basic.webp" alt="basicCard" width="290px" />
                </NavLink>
                <NavLink to="/category/filterData/65cbab1147f3a0198a40b543">
                    <img src="business.webp" alt="basicCard" width="290px" />
                </NavLink>
                <NavLink to="/category/filterData/65cc8831264789916da18898">
                    <img src="gaming.webp" alt="basicCard" width="290px" />
                </NavLink>
            </div>
            <br />
            <br />

            {/* Daily Usage Refurbished Laptops */}
            <div className="freshArrivalheading">
                <h1>Daily Usage Refurbished Laptops</h1>
            </div>

            <div className=" productsData container-grid">
                {
                    dell.slice(0, 8).map((currentProduct, index) => {
                        const base64String = btoa(
                            String.fromCharCode(...new Uint8Array(currentProduct.pImage.data.data))
                        );

                        return (
                            <div className=" productCard " key={index}>
                                <NavLink to={`/user/product-details/${currentProduct.pToken}`}>
                                    <div className="card-img">
                                        <img src={`data: image/png;base64, ${base64String}`} alt="Product Img" width="250px" height="250px" />
                                    </div>
                                    <div className="card-details">
                                        <div className="product-name">
                                            <h4>{currentProduct.pBrand}</h4>
                                        </div>
                                        <div className="product-price">
                                            <h4><FaIndianRupeeSign /> {currentProduct.pPrice}</h4>
                                        </div>
                                        <div className="product-description">
                                            <p className="fw-light">{currentProduct.pDescription}</p>
                                        </div>

                                    </div>
                                </NavLink>
                            </div>
                        )
                    })
                }
            </div >
            <div className="freshArrivalbtn text-center">
                <Link to="category/filterData/65cc8866264789916da18bd4">
                    <button ><h6>VIEW ALL</h6></button>
                </Link>
            </div>
            <br />
            <br />
            <br />

            {/* Hp Laptops */}
            <div className="freshArrivalheading">
                <h1>Refurbished HP Laptops</h1>
            </div>

            <div className=" productsData container-grid">
                {
                    hp.slice(0, 8).map((currentProduct, index) => {
                        const base64String = btoa(
                            String.fromCharCode(...new Uint8Array(currentProduct.pImage.data.data))
                        );

                        return (
                            <div className=" productCard " key={index}>
                                <NavLink to={`/user/product-details/${currentProduct.pToken}`}>
                                    <div className="card-img">
                                        <img src={`data: image/png;base64, ${base64String}`} alt="Product Img" width="250px" height="250px" />
                                    </div>
                                    <div className="card-details">
                                        <div className="product-name">
                                            <h4>{currentProduct.pBrand}</h4>
                                        </div>
                                        <div className="product-price">
                                            <h4><FaIndianRupeeSign /> {currentProduct.pPrice}</h4>
                                        </div>
                                        <div className="product-description">
                                            <p className="fw-light">{currentProduct.pDescription}</p>
                                        </div>

                                    </div>
                                </NavLink>
                            </div>
                        )
                    })
                }
            </div >
            <div className="freshArrivalbtn text-center">
                <Link to="category/filterData/65cbab3447f3a0198a40b59a">
                    <button ><h6>VIEW ALL</h6></button>
                </Link>
            </div>
            <br />
            <br />
            <ContinousSlider />
            <br />
            <br />

            <Testimonials />

        </>
    )
}


